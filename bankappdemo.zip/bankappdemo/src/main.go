package main

import (
	"fmt"
)

func main() {
	fmt.Println("Welcome to Go!")

	app.startBankServer()
}
